/* khean.h */

#ifndef _KHEAN_H_ 
#define _KHEAN_H_

#define BUFSIZE 512

int khean(void);
void khean_vol(int act);

#endif /* _KHEAN_H_ */
