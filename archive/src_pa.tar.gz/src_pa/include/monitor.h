/* monitor.h */

#ifndef _MONITOR_START_H_
#define _MONITOR_START_H_

void monitor_init(void);

#endif /* _MONITOR_START_H_ */
