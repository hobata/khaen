/* log.h */

#ifndef _LOG_H_
#define _LOG_H_

int log_(const char *fmt);
int log_str(const char *fmt, const char *prm);

#endif /* _LOG_H_ */

