#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <wiringPi.h>
#include <sys/time.h>

#include "press.h"
#include "key.h"
#include "led.h"
#include "log.h"
#include "khean.h"
#include "btn.h"

volatile  int8_t btnRed;
volatile  int8_t btnGreen;
volatile  int8_t btnBlue;
volatile  int8_t btnYellow;

extern int wiringpi_setup_flag;

static void calib(void)
{
	press_set_auto_zero(PRESS_AUTO_DIFF_FORCE);
}

int unshi_mode = 0;
static void unshi_on(void)
{
	unshi_mode = 1;
	led_set(3, LED_ON);
}
static void unshi_off(void)
{
	unshi_mode = 0;
	led_set(3, LED_OFF);
}
static void shtdwn(void)
{
	/* system shutdown */
	system("sudo poweroff");
}
void vol_up(void)
{
//	khean_vol(1);
}
void vol_down(void)
{
//	khean_vol(-1);
}

const int col_list[BTN_NUM] ={ RED, BLUE, GREEN, YELLOW };
static int menu_sts = 0;
static menu_t menu[][BTN_NUM] = {
{ /* normal */
	{&calib,		0},
	{NULL,		0},
	{&unshi_on,		1},
	{&shtdwn,	0},
},
{ /* unshi + volume */
	{&unshi_off,		0},
	{&vol_up, 		1},
	{NULL,		1},
	{&vol_down,		1},
},
};
int color2index(int color)
{
        int i = 0;

        while(i < BTN_NUM && col_list[i] != color){
                i++;
        }
        if (i == BTN_NUM){
                log_("wrong COLOR in cancel_chattering func.\n");
                exit(1);
        }
	return i;
}
void select_menu(int color)
{
	menu_t *p;
	color = color2index(color);
	p = &menu[menu_sts][color];
	if ( p->func != NULL){
		p->func();
	}
	menu_sts = p->n_sts;
}
static int8_t cancel_chattering(int8_t onoff, int color)
{
	static color_t btn[BTN_NUM];
	static int first = 0;
	struct timeval now;
	int i;

	if (first==0){ /* init */
		memset(btn, 0, sizeof(btn));
		color_t *pbtn = btn;
		for (i=0; i<BTN_NUM; i++){
			pbtn->color_index = i;
			pbtn->prev = BTN_OFF;
			pbtn++;
		}
		first++;
	}
	i = color2index(color);
	gettimeofday(&now, NULL);
	if (diff_ms(&now, &(btn[i].ti)) > KEY_CHATTERING_MS){
		if (onoff != btn[i].prev){
			btn[i].prev = onoff;
			btn[i].ti = now;
			return onoff;
		}
	}
	return btn[i].prev;
}
static int get_onoff(int color)
{
	int8_t tmp;

	/* negative logic -> positive logic*/
	tmp =  (~digitalRead(color)) & 0x1;
	return cancel_chattering(tmp, color);
	
}
void myIntrRed(void){
	int8_t tmp;

	int8_t ret = get_onoff(RED);

	//log_("ret get_onoff:%d\n", ret);

	piLock(BTN_LOCK);
	tmp = btnRed; /* backup <- not good */
	btnRed = ret;
	piUnlock(BTN_LOCK);
	if (tmp == BTN_OFF && ret == BTN_ON) {
		select_menu(RED);
	}
}
void myIntrGreen(void){
	int8_t tmp;
	int ret = get_onoff(GREEN);

	piLock(BTN_LOCK);
	tmp = btnGreen;
	btnGreen = ret;
	piUnlock(BTN_LOCK);
	if (tmp == BTN_OFF && ret == BTN_ON) {
		select_menu(GREEN);
	}
}
void myIntrBlue(void){
	int8_t tmp;
	int ret = get_onoff(BLUE);

	piLock(BTN_LOCK);
	tmp = btnBlue;
	btnBlue = ret;
	piUnlock(BTN_LOCK);
	if (tmp == BTN_OFF && ret == BTN_ON) {
		select_menu(BLUE);
	}
}
void myIntrYellow(void){
	int8_t tmp;
	int ret = get_onoff(YELLOW);
	piLock(BTN_LOCK);
	tmp = btnYellow;
	btnYellow = ret;
	piUnlock(BTN_LOCK);
	if (tmp == BTN_OFF && ret == BTN_ON) {
		select_menu(YELLOW);
	}
}

int btn_init(void)
{
	if (wiringpi_setup_flag == 0){
		wiringPiSetup();
		wiringpi_setup_flag = 1;
	}

	/* read initial value */
	myIntrRed();
	myIntrGreen();
	myIntrBlue();
	myIntrYellow();

	wiringPiISR(RED, INT_EDGE_BOTH, myIntrRed);
	wiringPiISR(GREEN, INT_EDGE_BOTH, myIntrGreen);
	wiringPiISR(BLUE, INT_EDGE_BOTH, myIntrBlue);
	wiringPiISR(YELLOW, INT_EDGE_BOTH, myIntrYellow);

	return 0;
}
