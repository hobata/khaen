// common.c

int wiringpi_setup_flag = 0;
