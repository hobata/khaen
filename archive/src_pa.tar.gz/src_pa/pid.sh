#!/bin/sh
ps -e | grep khean | awk '{print $1}' | head -1

# `ps -e | grep khean | head -1 | awk '{print "kill ", $1}'`
