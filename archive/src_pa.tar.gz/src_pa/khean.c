/*
 *  khean.c
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <pulse/simple.h>
#include <pulse/error.h>
#include <getopt.h>
#include <sys/time.h>
#include <math.h>
#include <signal.h>
#include "pcm.h"
#include "press.h"
#include "khean.h"
#include "log.h"

extern int g_daemon;
static char strbuf[512];
static int sigTermArrived = 0;
void sigint(int);
void sigkill(int);
void sigterm(int);

/* main */
int khean(void){
        int method = 2; /* async */

        //khean_vol(0);
        press_init();
        log_("khean: init.done\n");

  if (!g_daemon){
        if (SIG_ERR == signal(SIGINT, sigint)) { /* CTRL+C */
                log_("failed to set signal handler SIGINT\n");
                exit(1);
        }
  }else{
        /* ERROR !
        if (SIG_ERR == signal(SIGKILL, sigkill)) {
                log_("failed to set signal handler:SIGLKILL\n");
                exit(1);
        }
        */
  }

    /* The Sample format to use */
    static const pa_sample_spec ss = {
        .format = PA_SAMPLE_S16LE,
        .rate = 48000,
        .channels = 2
    };
    pa_simple *s = NULL;
    int ret = 1;
    int error;
    
    /* Create a new playback stream */
    if (!(s = pa_simple_new(NULL, "khean", PA_STREAM_PLAYBACK, NULL, "playback", &ss, NULL, NULL, &error))) {
        fprintf(stderr, __FILE__": pa_simple_new() failed: %s\n", pa_strerror(error));
        goto finish;
    }
    for (;;) {
        uint8_t buf[BUFSIZE];
        ssize_t r;
#if 0
        pa_usec_t latency;
        if ((latency = pa_simple_get_latency(s, &error)) == (pa_usec_t) -1) {
            fprintf(stderr, __FILE__": pa_simple_get_latency() failed: %s\n", pa_strerror(error));
            goto finish;
        }
        fprintf(stderr, "%0.0f usec    \r", (float)latency);
#endif
	if (sigTermArrived){
		pcm_free();
		goto finish;
	}
        /* Read some data ... */
	pcm_read_pa((short*) buf, BUFSIZE >> 2); /* samples = BUFSIZE/4 */
	r = BUFSIZE;
        /* ... and play it */
        if (pa_simple_write(s, buf, (size_t) r, &error) < 0) {
            fprintf(stderr, __FILE__": pa_simple_write() failed: %s\n", pa_strerror(error));
            goto finish;
        }
    }
    /* Make sure that every single sample was played */
    if (pa_simple_drain(s, &error) < 0) {
        fprintf(stderr, __FILE__": pa_simple_drain() failed: %s\n", pa_strerror(error));
        goto finish;
    }
    ret = 0;
finish:
    if (s)
        pa_simple_free(s);
    return ret;
}
void sigkill(int sig) {
        sigint(sig);
}
void sigterm(int sig) {
        sigint(sig);
}
void sigint(int sig) {
        sigTermArrived = 1;
}

