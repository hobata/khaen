#!/bin/sh

gcc sensor.c -lwiringPi -o spi
