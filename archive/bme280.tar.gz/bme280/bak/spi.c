#include <stdio.h>
#include <errno.h>
#include <wiringPiSPI.h>

#define SPI_CH	0
#define READ_ACS	0x80

int readSPI(unsigned char addr, unsigned char *data);
int writeSPI(unsigned char addr, unsigned char data);
int readAll(void);

int readAll(void)
{
	unsigned char addr, data[100];
	unsigned char val;

	/* read all register */
	addr = 0x88;
	printf("%04x:", addr);
	for (; addr <= 0xfe; addr++){
		readSPI(addr, data+1);
		printf("%02x ", data[1]);
		if (addr % 0x10 == 0xf){
			printf("\n%04x:", addr+1);
		}else if (addr % 8 == 0x7){
			printf(" ");
		} 
	}
	printf("\n\n");

	return 0;
}

int readSPI(unsigned char addr, unsigned char *data)
{
	unsigned char array[100];
	int ret;

	array[0] = addr | 0x80; //set 0x80 bit 
	array[1] = 0x0;
	ret = wiringPiSPIDataRW (SPI_CH, array, 2);
	if (ret == -1){
		printf("%s:errno:%d\n", __func__, errno);
		return 1;
	}
	*data = array[1]; 

	return 0;
}

int writeSPI(unsigned char addr, unsigned char data)
{
	unsigned char array[2];
	int ret;

	array[0] = addr & 0x7f; //clear 0x80 bit 
	array[1] = data;
	ret = wiringPiSPIDataRW (SPI_CH, array, 2);
	if (ret == -1){
		printf("%s:errno:%d\n", __func__, errno);
		return 1;
	}

	return 0;
}

int main(int argc, char* argv[])

{
	int ret, fd;
	unsigned char addr;
	unsigned char val;

	fd =  wiringPiSPISetup (SPI_CH, 10000000) ;
	if (fd == -1){
		printf("wiringPiSPISetup:errno:%d\n", errno);
		return 1;
	}else{
		printf("wiringPiSPISetup:fd:%d\n", fd);
	}
	/* set ctrl_meas */ 
	addr = 0xf4;
	// osrs_p = 001, osrs_t = 001, mode = 11
	val = (0x1 << 5) | (0x1 << 2) | 0x3; 
	writeSPI(addr, val);

	/* read all register */
	readAll();

	return 0;
}

