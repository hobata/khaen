// control pressure sensor
// sensor.c
// 2017.12.10

#include <stdio.h>
#include <errno.h>
#include <time.h>
#include <wiringPiSPI.h>

// #define _DEBUG

#define SPI_CH	0
#define TEMP_ADDR 0xfa
#define PRESS_ADDR 0xf7

unsigned short	dig_T1;
signed short	dig_T2, dig_T3;
unsigned short	dig_P1;
signed short	dig_P2, dig_P3, dig_P4, dig_P5;
signed short	dig_P6, dig_P7, dig_P8, dig_P9;
unsigned char	dig_H1;
signed short	dig_H2, dig_H4, dig_H5;
unsigned char	dig_H3;
signed char	dig_H6;

#define BMP280_S32_t	long signed int
#define BMP280_U32_t	long unsigned int
#define BMP280_S64_t	long long signed int

int readSPI(unsigned char addr, unsigned char *data);
int writeSPI(unsigned char addr, unsigned char data);

int readREGALL(void)
{
	unsigned char addr, data[100];
	unsigned char val;

	/* read all register */
	addr = 0x88;
	printf("%04x:", addr);
	for (; addr <= 0xfe; addr++){
		readSPI(addr, data+1);
		printf("%02x ", data[1]);
		if (addr % 0x10 == 0xf){
			printf("\n%04x:", addr+1);
		}else if (addr % 8 == 0x7){
			printf(" ");
		} 
	}
	printf("\n\n");

	return 0;
}

int readSPI(unsigned char addr, unsigned char *data)
{
	unsigned char array[2];
	int ret;

	array[0] = addr | 0x80; //set 0x80 bit 
	array[1] = 0x0;
	ret = wiringPiSPIDataRW (SPI_CH, array, 2);
	if (ret == -1){
		printf("%s:errno:%d\n", __func__, errno);
		return 1;
	}
	*data = array[1]; 

	return 0;
}

int writeSPI(unsigned char addr, unsigned char data)
{
	unsigned char array[2];
	int ret;

	array[0] = addr & 0x7f; //clear 0x80 bit 
	array[1] = data;
	ret = wiringPiSPIDataRW (SPI_CH, array, 2);
	if (ret == -1){
		printf("%s:errno:%d\n", __func__, errno);
		return 1;
	}

	return 0;
}

// calculation formula rev.1.1 in BME280 data sheet

// Returns temperature in DegC, resolution is 0.01 DegC. Output value of “5123” equals 51.23 DegC.

// t_fine carries fine temperature as global value
BMP280_S32_t t_fine;

BMP280_S32_t bmp280_compensate_T_int32(BMP280_S32_t adc_T)
{
BMP280_S32_t var1, var2, T;
var1 = ((( (adc_T>>3)-((BMP280_S32_t)dig_T1<<1))) * ((BMP280_S32_t)dig_T2)) >> 11;
var2 = (((((adc_T>>4) - ((BMP280_S32_t)dig_T1)) * ((adc_T>>4) - ((BMP280_S32_t)dig_T1))) >> 12) * ((BMP280_S32_t)dig_T3)) >> 14;
t_fine = var1 + var2;
T = (t_fine * 5 + 128) >> 8;
return T;
}

// Returns pressure in Pa as unsigned 32 bit integer in Q24.8 format (24 integer bits and 8 fractional bits).
// Output value of “24674867” represents 24674867/256 = 96386.2 Pa = 963.862 hPa

BMP280_U32_t bmp280_compensate_P_int64(BMP280_S32_t adc_P)
{
BMP280_S64_t var1, var2, p;
var1 = ((BMP280_S64_t)t_fine) - 128000;
var2 = var1 * var1 * (BMP280_S64_t)dig_P6;
var2 = var2 + ((var1*(BMP280_S64_t)dig_P5)<<17);
var2 = var2 + (((BMP280_S64_t)dig_P4)<<35);
var1 = ((var1 * var1 * (BMP280_S64_t)dig_P3)>>8) + ((var1 * (BMP280_S64_t)dig_P2)<<12);
var1 = (((((BMP280_S64_t)1)<<47)+var1))*((BMP280_S64_t)dig_P1)>>33;
if (var1 == 0)
{
return 0; // avoid exception caused by division by zero
}
p = 1048576-adc_P;
p = (((p<<31)-var2)*3125)/var1;
var1 = (((BMP280_S64_t)dig_P9) * (p>>13) * (p>>13)) >> 25;
var2 = (((BMP280_S64_t)dig_P8) * p) >> 19;
p = ((p + var1 + var2) >> 8) + (((BMP280_S64_t)dig_P7)<<4);
return (BMP280_U32_t)p;
}

int readSPIm(unsigned char addr, unsigned char *data, int len)
{
	int i, ret;

	for (i=0; i < len; i++){
		data[i] = (addr + i) | 0x80; //set 0x80 bit 
	}
	data[i] = 0x0;
	ret = wiringPiSPIDataRW (SPI_CH, data, len+1);
	if (ret == -1){
		printf("%s:errno:%d\n", __func__, errno);
		return 1;
	}

	return 0;
}

int readUS(unsigned char addr, unsigned short *data)
{
	unsigned char array[3];
	unsigned short val;

	readSPIm(addr, array, 2);
	val = array[1];
	val += ( (unsigned short)array[2] ) << 8;
	*data = val;

	return 0;
}
int readSS(unsigned char addr, signed short *data)
{
	return readUS(addr, (unsigned short *)data);
}
int readSC(unsigned char addr, signed char *data)
{
	return readSPI(addr, (unsigned char*)data);
}
int readUC(unsigned char addr, unsigned char *data)
{
	return readSPI(addr, data);
}

int readSSL(unsigned char addr, signed short *data)
{
	signed short t_val;
	unsigned char array[3];

	readSPIm(addr, array, 2);
	*data = ((unsigned short)array[1]) << 4 | array[2] & 0xf;

	return 0;
}
int readSSM(unsigned char addr, signed short *data)
{
	signed short t_val;
	unsigned char array[3];

	readSPIm(addr, array, 2);
	*data = (array[1] >> 4) | ( ((unsigned short)array[2]) << 4);

	return 0;
}

int readParam(void)
{
	readUS(0x88, &dig_T1);
	readSS(0x8a, &dig_T2);
	readSS(0x8c, &dig_T3);
	readUS(0x8e, &dig_P1);
	readSS(0x90, &dig_P2);
	readSS(0x92, &dig_P3);
	readSS(0x94, &dig_P4);
	readSS(0x96, &dig_P5);
	readSS(0x98, &dig_P6);
	readSS(0x9a, &dig_P7);
	readSS(0x9c, &dig_P8);
	readSS(0x9e, &dig_P9);
	readUC(0xa1, &dig_H1);
	readSS(0xe1, &dig_H2);
	readUC(0xa3, &dig_H3);
	readSSL(0xe4, &dig_H4);
	readSSM(0xe5, &dig_H5);
	readSC(0xe7, &dig_H6);
#ifdef _DEBUG
	printf("T:%d:%x %d:%x %d:%x\n",
		dig_T1, dig_T1, dig_T2, dig_T2, dig_T3, dig_T3 );
	printf("P:%d:%x %d:%x %d:%x  %d:%x %d:%x %d:%x %d:%x  %d:%x %d:%x\n",
		dig_P1, dig_P1, dig_P2, dig_P2, dig_P3, dig_P3,
		dig_P4, dig_P4, dig_P5, dig_P5,
		dig_P6, dig_P6, dig_P7, dig_P7, dig_P8, dig_P8,
		dig_P9, dig_P9 );
	printf("H:%d:%x %d:%x %d:%x %d:%x  %d:%x %d:%x\n",
		dig_H1, dig_H1, dig_H2, dig_H2, dig_H3, dig_H3,
		dig_H4, dig_H4, dig_H5, dig_H5, dig_H6, dig_H6 );
#endif
	return 0;
}
int init(void)
{
	int ret, fd;
	unsigned char addr, val;

	fd =  wiringPiSPISetup (SPI_CH, 10000000) ;
	if (fd == -1){
		printf("wiringPiSPISetup:errno:%d\n", errno);
		return 1;
	}else{
		printf("wiringPiSPISetup:fd:%d\n", fd);
	}
	readParam();
	/* set config */ 
	addr = 0xf5;
	// t_sb = 000, filter = 000, spi3w_en = 0
	val = (0x0 << 5) | (0x0 << 2) | 0x0; 
	writeSPI(addr, val);
	/* set ctrl_meas */ 
	addr = 0xf4;
	// osrs_p = 001, osrs_t = 001, mode = 11
	val = (0x1 << 5) | (0x1 << 2) | 0x3; 
	writeSPI(addr, val);
	/* set ctrl_hum */ 
	addr = 0xf3;
	// osrs_h = 000
	val = 0x0; 
	writeSPI(addr, val);

	return 0;
}
int readMea(unsigned char addr, signed long *val)
{
	unsigned char sts;
	unsigned short readout;

	/* stats is not measuring and im_updata is done */
	do {
		readSPI(0xf3, &sts);
	} while (sts & 0x9 != 0);
	readUS(addr, &readout);
	/* reverse significant bit */
	*val = (readout & 0x00ff) << 8 | (readout & 0xff00) >> 8;
	*val <<= 4; /* *_xlsb */

	return 0;
}
#define MEA_ADDR 0xf7 
int readMea2(signed long *ptemp, unsigned long *ppress)
{
	unsigned char sts;
	unsigned char array[7];

	/* stats is not measuring and im_updata is done */
	do {
		readSPI(0xf3, &sts);
	} while (sts & 0x9 != 0);

	readSPIm(MEA_ADDR, array, 6);
	*ppress = (signed long ) ( (unsigned long)array[1] << 12 
		| (unsigned long)array[2] << 4
		| array[3] >> 4 );
	*ptemp = (unsigned long)array[4] << 12 
		| (unsigned long)array[5] << 4
		| array[6] >> 4;
#ifdef _DEBUG
	printf("%02x %02x %02x %02x  %02x %02x\n",
		array[1], array[2], array[3], array[4], array[5], array[6]);
	printf("temp:%ld, press%ld\n", *ptemp, *ppress);
#endif

	return 0;
}
int main(int argc, char* argv[])
{
	signed long temp;
	unsigned long press;
	int i;
	struct timespec req, rem;

	init();
	/* set 10 ms */
	req.tv_sec = 0;
	req.tv_nsec = 10000000;
	readREGALL();
	i = 0;
	for (i=0; i < 100; i++){
		nanosleep(&req, &rem); /* 10ms */
#ifdef _DEBUG
                readMea(TEMP_ADDR, &temp);
                readMea(PRESS_ADDR, (signed long*)&press);
		printf("1:temp:%ld, press%ld\n", temp, press);
#endif
		readMea2(&temp, &press);
#ifdef _DEBUG
		printf("2:temp:%ld, press%ld\n", temp, press);
#endif

		/* press is Q24.8 format */
		temp = bmp280_compensate_T_int32(temp);
		press = bmp280_compensate_P_int64(press);
		printf("%02d:temp:%ld, press:%lu.%d\n", i, temp,
			press >> 8, press & 0xff);
	}
	return 0;
}

